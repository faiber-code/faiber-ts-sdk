# @faiber/faiber-task

Typed client for every authenticated Faiber Tasks route. Tasks is the sandbox-local authority
for projects, work items, sprints, scoped access grants, reporting, comments, agent proposals,
and realtime invalidation events.

```bash
npm install @faiber/faiber-task
```

```ts
import { FaiberClient, TaskApi } from "@faiber/faiber-task";

const task = new TaskApi(new FaiberClient("task", {
  domains: { task: process.env.FAIBER_TASK_URL! },
  authMode: "bearer",
  getAccessToken: async () => accessToken,
}));

const projects = await task.listProjects({ mode: "software" });
const personal = await task.ensurePersonalProject();
const shared = await task.createSharedProject({ name: "Household" });
const item = await task.createWorkItem(input, crypto.randomUUID());
await task.transitionWorkItem(item.data.data.id, item.data.data.version, { status: "in_progress" });
```

All methods return complete Axios responses and accept shared request options, including
`AbortSignal`. Mutable aggregates emit ETags; updates accept the integer version and send it
as `If-Match`. Retried work-item creates must reuse the same idempotency key. `openEvents`
opens the authenticated SSE invalidation stream with the fetch adapter by default.

`ensurePersonalProject` is idempotent and grants the signed-in user only project-level
access. `createSharedProject` creates a general project with an owner grant and an
acceptance-required assignment policy. These are generic Task APIs; use the
existing `createProject` method for software or marketing project modes.

All methods return complete Axios responses. On transport or API failure, catch
the Axios error and inspect `error.response?.status` and the service response.
Pass an `AbortSignal` through the final request-options argument to cancel calls.

IDP proves identity and the configured global Task permission. Task independently enforces
workspace, team, project, and work-item grants. Global roles never bypass local grants.

### Checklists, collaborators, and reminders

`projectChecklists` and `checklist` return atomic task/checklist snapshots. Save with `replaceChecklist(taskId, taskVersion, {items})`; a 409 requires reloading before retry. `projectMembers` lists project grants, and `removeProjectMember` requires project membership management rights (owners cannot be removed). `reminder`, `saveReminder`, and `removeReminder` operate only on the current user's reminder. Use version 0 for first creation and the returned reminder version thereafter. Reminders accept future ISO timestamps, IANA time zones, and `once`, `daily`, or `monthly` recurrence. Task creation accepts an optional `reminder` atomically. Delivery is handled by Messenger; these APIs never grant access to another user's inbox. All operations preserve Axios responses and support cancellation through request options.

### Reviewed workspace changes

`task.workspaceAssistant` provides scoped task/note queries, category folders, saved planning preferences, and durable review proposals. Queries return an exact `total`, cursor pages, and retrieval time. Date ranges are inclusive at `from` and exclusive at `until`; `completed_by_me` uses recorded completion actors, including tasks subsequently reopened. Use `owner_id` for assignment-based lists.

```ts
const result = await task.workspaceAssistant.query({
  project_id: spaceId, owner_id: signedInUserId, active_only: true,
  from: tomorrowStart, until: nextDayStart, limit: 200,
});
const proposal = await task.workspaceAssistant.propose({
  conversation_id: conversationId, project_id: spaceId,
  request_id: crypto.randomUUID(),
  operations: [{ kind: 'update', id: taskId, expected_version: currentVersion,
    patch: { due_at: tomorrowStart } }],
});
// Render proposal.data.data.preview and collect the user's review first.
const applied = await task.workspaceAssistant.apply(
  proposal.data.data.id, proposal.data.data.revision,
);
```

`revise` validates edited operations and produces a new revision. On a conflict, `refresh` rebuilds the preview from current records; review it again before applying. Approval is transactional and idempotent for the same revision. All methods inherit caller authentication, cancellation, and Axios error handling. They require `task:access:use` plus each operation's current Task capability; project-owner billing never grants access. Initial `createWorkItem` checklists and personal reminders are committed together with the task.
Administrative 2Done reports: `adminUserPlans({ user_ids })` returns sandbox subscriptions for up to 100 comma-separated user UUIDs; `incomeReport({ from, to, plan?, page? })` returns confirmed purchases and daily cash income in toman. Dates are inclusive YYYY-MM-DD in Asia/Tehran, at most 366 days. Both require verified administrator role and Task access. Methods retain the full Axios response and accept cancellation options.


### Boards, private sources and note memory

`task.collaboration` exposes versioned shared workflows, private attachments, note media,
imports, indexing and owner-pooled allowances. Inspect `config()` before offering a
feature and use its deployment-specific file/audio ceilings. Stage IDs and canonical
categories remain stable when names change. Only space managers edit shared stages;
participants can transition only assigned tasks. A 409 requires refreshed versions and
an updated preview before retrying a move.

Create an attachment reservation with a stable request UUID and SHA-256 checksum, upload
with `uploadAttachment`, then poll `attachment` until scanning marks it clean. Bind clean
IDs to a comment or use `attachNoteMedia`/`setNoteCover` with the current note version.
Downloads recheck Task permissions. Storage remains charged while retained originals
exist; unbinding a file preserves note text and schedules abandoned-object cleanup.

`startNoteImport` accepts a clean private original; `startSourceImport` accepts a public
HTTP(S) page. Poll `noteImport`, show extraction and provenance, then explicitly approve
with `applyNoteImport`. One conversion consumes one import; OCR and audio also use their
configured allowances. Cancellation and retry use the job version. Never automatically
apply extracted content. `workspaceAssistant.propose` supports `import_note` with the
current import/note versions, append/replace mode and an optional reviewed summary; the
original stays attached. A changed source or note returns 409.

`searchNotes` defaults to one specified project and accepts up to nine additional
accessible projects. Task reauthorizes every returned note/version before returning a
citation. `noteIndexing` and `retryNoteIndexing` expose progress and authorized retry.
New content remains directly readable through explicit note selection during indexing.
Saved supported originals are extracted asynchronously without changing note writing.

Reviewed `archive_note` operations take `archived: true` or `false`. They retain content,
files and history. Default assistant queries and knowledge search omit archived notes;
explicit note selection remains permission checked. Use `include_archived: true` only
when the user requests archived records. All methods preserve Axios responses and accept
request options, including cancellation signals.

Internal operations require a trusted server credential and current tenant scope. Never call them from a browser or expose the service credential to application users.

## Configurable feedback requests (0.24.1)

`task.feedback.capabilities()` returns current verified reporting roles and readiness. A new Task instance has no policy or workflow preset. A workspace manager configures it in `/dashboard/settings/feedback`; it is stored only in that sandbox database. Clients must not encode role mappings or stage counts.

Use exported `ReportContext` and `SubmitFeedbackRequest` types, initialize/upload/complete private screenshot evidence, then call `task.feedback.submit(input, crypto.randomUUID())`. Keep the same key and body for retries. Screenshots can be unavailable without blocking submission. `list`, `detail`, `decide`, and authorized `attachmentContent` preserve server ownership and local review scope. A decision uses `expected_version`; stale versions return 409. Only the configured final assignment stage creates a task. `current_stage` contains its bilingual label and action kind. Existing reports retain the submitted route snapshot after policy edits. Management methods require local `workspace.manage`; policy writes use the current version (zero initializes).

All calls retain Axios status/headers, authenticated cookies or bearer tokens, AbortSignal cancellation and transport errors. Never submit hidden answers, credentials, signed media URLs or private evidence in broker events.
